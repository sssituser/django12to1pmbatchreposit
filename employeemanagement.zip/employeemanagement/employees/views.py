from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags

from .models import Employee
from .forms import EmployeeForm
from .utils import get_updated_fields


# ==============================
# EMPLOYEE CREATE
# ==============================
def employee_create(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST,request.FILES)
        if form.is_valid():
            employee = form.save()

            # Professional HTML email
            html_content = render_to_string(
                'employees/emails/employee_created.html',
                {'employee': employee}
            )

            email = EmailMultiAlternatives(
                subject='Employee Registration Confirmation',
                body=strip_tags(html_content),
                from_email=settings.EMAIL_HOST_USER,
                to=[employee.email]
            )
            email.attach_alternative(html_content, "text/html")
            email.send()

            return redirect('employee_list')
    else:
        form = EmployeeForm()

    return render(request, 'employees/form.html', {'form': form})


# ==============================
# EMPLOYEE LIST
# ==============================
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, 'employees/list.html', {'employees': employees})


# ==============================
# EMPLOYEE UPDATE
# ==============================
def employee_edit(request, id):
    employee = get_object_or_404(Employee, id=id)
    old_employee = Employee.objects.get(id=id)

    form = EmployeeForm(request.POST or None, instance=employee)

    if form.is_valid():
        updated_employee = form.save()
        changes = get_updated_fields(old_employee, updated_employee)

        if changes:
            html_content = render_to_string(
                'employees/emails/employee_updated.html',
                {
                    'employee': updated_employee,
                    'changes': changes
                }
            )

            email = EmailMultiAlternatives(
                subject='Employee Profile Update Notification',
                body=strip_tags(html_content),
                from_email=settings.EMAIL_HOST_USER,
                to=[updated_employee.email]
            )
            email.attach_alternative(html_content, "text/html")
            email.send()

        return redirect('employee_list')

    return render(request, 'employees/form.html', {'form': form})


# ==============================
# EMPLOYEE DELETE
# ==============================
def employee_delete(request, id):
    employee = get_object_or_404(Employee, id=id)

    html_content = render_to_string(
        'employees/emails/employee_deleted.html',
        {'employee': employee}
    )

    email = EmailMultiAlternatives(
        subject='Employee Profile Deactivation Notice',
        body=strip_tags(html_content),
        from_email=settings.EMAIL_HOST_USER,
        to=[employee.email]
    )
    email.attach_alternative(html_content, "text/html")
    email.send()

    employee.delete()
    return redirect('employee_list')
