from django.core.mail import send_mail
from django.conf import settings
from twilio.rest import Client

def send_email(subject, message, to_email):
    send_mail(subject, message, settings.EMAIL_HOST_USER, [to_email])

def send_sms(message, phone):
    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    client.messages.create(
        body=message,
        from_=settings.TWILIO_PHONE_NUMBER,
        to=phone
    )
