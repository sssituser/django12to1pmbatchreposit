def get_updated_fields(old, new):
    changes = []
    for field in old._meta.fields:
        name = field.name
        if getattr(old, name) != getattr(new, name):
            changes.append(
                f"{name}: {getattr(old, name)} → {getattr(new, name)}"
            )
    return changes
