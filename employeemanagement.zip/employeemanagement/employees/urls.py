from django.urls import path
from .views import *

urlpatterns = [
    path('', employee_list, name='employee_list'),
    path('add/', employee_create, name='employee_add'),
    path('edit/<int:id>/', employee_edit, name='employee_edit'),
    path('delete/<int:id>/', employee_delete, name='employee_delete'),
]
